'use strict';

module.exports = function(Videos) {

};
