'use strict';

module.exports = function(Books) {

};
