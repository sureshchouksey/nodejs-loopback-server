'use strict';

module.exports = function(Appdetails) {

};
