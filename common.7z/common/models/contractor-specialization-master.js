'use strict';

module.exports = function(Contractorspecializationmaster) {

};
