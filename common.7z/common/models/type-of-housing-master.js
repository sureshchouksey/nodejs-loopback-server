'use strict';

module.exports = function(Typeofhousingmaster) {

};
