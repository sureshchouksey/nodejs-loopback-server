'use strict';

module.exports = function(Contractoraffiliationmapping) {

};
