'use strict';

module.exports = function(Subspecializationmapping) {

};
