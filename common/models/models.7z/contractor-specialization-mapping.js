'use strict';

module.exports = function(Contractorspecializationmapping) {

};
