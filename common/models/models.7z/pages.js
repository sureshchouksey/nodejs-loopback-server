'use strict';

module.exports = function(Pages) {

};
