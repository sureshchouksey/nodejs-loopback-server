'use strict';

module.exports = function(Workgroup) {

};
