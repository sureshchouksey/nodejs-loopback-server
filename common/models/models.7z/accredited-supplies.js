'use strict';

module.exports = function(Accreditedsupplies) {

};
