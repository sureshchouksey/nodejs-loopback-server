'use strict';

module.exports = function(Constructionstagemapping) {

};
