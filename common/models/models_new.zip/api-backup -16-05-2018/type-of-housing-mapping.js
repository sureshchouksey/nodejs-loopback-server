'use strict';

module.exports = function(Typeofhousingmapping) {

};
