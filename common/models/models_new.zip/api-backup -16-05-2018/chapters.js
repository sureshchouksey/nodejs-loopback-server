'use strict';

module.exports = function(Chapters) {

};
