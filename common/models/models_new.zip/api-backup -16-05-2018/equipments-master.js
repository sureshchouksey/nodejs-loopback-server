'use strict';

module.exports = function(Equipmentsmaster) {

};
