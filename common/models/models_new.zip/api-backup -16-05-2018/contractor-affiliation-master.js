'use strict';

module.exports = function(Contractoraffiliationmaster) {

};
