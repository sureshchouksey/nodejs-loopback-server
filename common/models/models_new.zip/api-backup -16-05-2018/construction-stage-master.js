'use strict';

module.exports = function(Constructionstagemaster) {

};
