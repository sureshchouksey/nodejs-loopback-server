'use strict';

module.exports = function(Municipality) {

};
