'use strict';

module.exports = function(Subspecializationmaster) {

};
